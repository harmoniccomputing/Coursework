

SELECT 
    c.customerName,
    p.amount
FROM 
    Customers c
JOIN 
    Payments p ON c.customerNumber = p.customerNumber
WHERE 
    p.amount > (SELECT AVG(amount) FROM Payments);


