
SELECT DISTINCT 
    c.customerName
FROM 
    Customers c
JOIN 
    Payments p ON c.customerNumber = p.customerNumber
JOIN 
    Orders o ON c.customerNumber = o.customerNumber
WHERE 
    p.paymentDate > o.shippedDate;

    
