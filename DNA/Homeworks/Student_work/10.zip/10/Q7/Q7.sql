
SELECT p.productName
FROM Products as p
JOIN 
    (
        SELECT 
            productLine,
            AVG(quantityInStock) AS avgStock
        FROM Products
        GROUP BY productLine
    ) AS avgStockPerCategory 
ON 
    p.productLine = avgStockPerCategory.productLine
WHERE 
    p.quantityInStock > avgStockPerCategory.avgStock;

