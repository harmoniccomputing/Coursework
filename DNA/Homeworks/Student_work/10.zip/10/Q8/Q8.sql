
CREATE VIEW customer_payment_history AS
SELECT 
    c.customerName,
    o.orderNumber,
    p.paymentDate,
    p.amount as amountpaid
FROM Customers as c
JOIN Orders as o ON c.customerNumber = o.customerNumber
JOIN Payments as p ON c.customerNumber = p.customerNumber
ORDER BY p.paymentDate DESC;



