CREATE VIEW shipped_orders_detail AS
SELECT 
    o.orderNumber,
    o.orderDate,
    o.shippedDate,
    c.customerName,
    c.salesRepEmployeeNumber as employeeNumber
FROM Orders as o
JOIN Customers as c ON o.customerNumber = c.customerNumber
WHERE o.orderStatus = 'Shipped'
ORDER BY o.orderDate DESC;

