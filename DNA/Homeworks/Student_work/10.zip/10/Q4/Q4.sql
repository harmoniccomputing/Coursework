
SELECT  cu.customerName
FROM Customers as cu
LEFT JOIN Orders as o ON cu.customerNumber = o.customerNumber
WHERE o.orderNumber IS NULL;

