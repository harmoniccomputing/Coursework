SELECT c.customerName, SUM(od.quantityOrdered * od.priceEach) AS totalOrderAmount 
FROM Customers as c 
JOIN Orders as o ON c.customerNumber = o.customerNumber
JOIN OrderDetails as od ON o.orderNumber = od.orderNumber 
GROUP BY c.customerName;


