SELECT 
    c.customerName,
    c.postalCode,
    c.city
FROM 
    Customers c
JOIN 
    Offices o ON c.postalCode = o.postalCode;




