
SELECT c.customerName, c.creditLimit, 
       SUM(od.quantityOrdered * od.priceEach) AS totalOrdered
FROM Customers c
JOIN Orders o ON c.customerNumber = o.customerNumber
JOIN OrderDetails od ON o.orderNumber = od.orderNumber
GROUP BY c.customerNumber
HAVING totalOrdered > 0.01 * c.creditLimit;

