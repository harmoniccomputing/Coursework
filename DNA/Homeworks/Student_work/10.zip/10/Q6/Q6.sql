
SELECT 
    e.employeeNumber as employeeID ,
    CONCAT(e.firstName, ' ', e.lastName) as employeeName,
    c.customerName as customerName
FROM Employees as e
INNER JOIN Customers as c ON e.employeeNumber = c.salesRepEmployeeNumber
ORDER BY e.employeeNumber,c.customerName;

