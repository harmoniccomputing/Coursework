
SELECT e.employeeNumber, e.firstName, e.lastName
FROM Employees e
LEFT JOIN Employees e2 ON e.employeeNumber = e2.reportsTo
WHERE e2.employeeNumber IS NULL;


