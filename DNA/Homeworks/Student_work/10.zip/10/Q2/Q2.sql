SELECT p.productName, SUM(od.quantityOrdered * od.priceEach) AS totalSales 
FROM Products as p 
JOIN OrderDetails as od ON p.productCode = od.productCode 
GROUP BY p.productName 
ORDER BY TotalSales
DESC LIMIT 5; 

