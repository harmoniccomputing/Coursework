SELECT c.customerName, 
       SUM(od.quantityOrdered * od.priceEach) AS totalPurchased
FROM Customers c
JOIN Orders o ON c.customerNumber = o.customerNumber
JOIN OrderDetails od ON o.orderNumber = od.orderNumber
GROUP BY c.customerNumber
ORDER BY totalPurchased DESC
LIMIT 1;


