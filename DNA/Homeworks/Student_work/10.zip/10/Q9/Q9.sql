SELECT productName
FROM Products
GROUP BY productName
HAVING COUNT(DISTINCT productVendor) > 1;
