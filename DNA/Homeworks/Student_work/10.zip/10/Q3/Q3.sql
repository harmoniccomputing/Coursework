DELETE FROM OrderDetails 
WHERE orderNumber IN (
    SELECT orderNumber 
    FROM Orders 
    WHERE orderStatus =  'Pending' 
    AND orderDate < DATE_SUB(CURDATE(), INTERVAL 1 MONTH)
);
DELETE FROM Orders 
WHERE orderNumber IN (
    SELECT orderNumber FROM ( 
        SELECT orderNumber 
        FROM Orders 
        WHERE orderStatus = 'Pending' 
        AND orderDate < DATE_SUB(CURDATE(), INTERVAL 1 MONTH)
    ) AS alias
);

